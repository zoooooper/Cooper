# NEON RANGE — 3D Drone Tagger

A browser-based 3D arcade game. It uses Three.js from jsDelivr, so an internet connection is needed.

## Play locally
Because this page uses JavaScript modules, opening `index.html` directly as a `file://` page may be blocked by browser security. Use a simple local web server or publish it with GitHub Pages.

## Publish with GitHub Pages
1. Create a new repository on GitHub.
2. Upload `index.html` and `.nojekyll` to the top level of the repository.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. Open the website address shown in the Pages settings.

## Controls
- W, A, S, D: move
- Mouse: look around (the game locks the mouse while playing)
- Click: scan the drone beneath the centre reticle
- Space: jump
- 1–6: change scan colour

Player XP and the top-five leaderboard are stored in the current browser using local storage. They are not shared between different players or devices.
